import React, { useEffect } from 'react';
//import {axiosConfig} from './helpers'
import { Button } from 'semantic-ui-react'
import Layout from './components/layout'
const App = (props) => {
  return(
    <div>
      <Layout />
    </div>
  )
}

export default App;

